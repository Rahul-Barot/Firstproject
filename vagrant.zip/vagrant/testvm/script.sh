#!/bin/bash

touch file-created-by-script.txt
apt-get update
apt-get install nginx -y
